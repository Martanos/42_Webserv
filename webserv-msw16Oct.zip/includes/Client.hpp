// Client.hpp
#ifndef CLIENT_HPP
#define CLIENT_HPP

#include "DefaultStatusMap.hpp"
#include "FileDescriptor.hpp"
#include "HttpRequest.hpp"
#include "HttpResponse.hpp"
#include "Logger.hpp"
#include "MimeTypes.hpp"
#include "RequestRouter.hpp"
#include "RingBuffer.hpp"
#include "Server.hpp"
#include "ServerMap.hpp"
#include "SocketAddress.hpp"
#include "StringUtils.hpp"
#include <fcntl.h>
#include <netinet/in.h>
#include <string>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

// This class represents the client connection it is simply the
// orchestrator of client operations
// Http requests are handled by http request class
// Request routing class takes care of method operations
// Http response class takes care of response generation and sending
class Client
{
public:
	enum State
	{
		CLIENT_WAITING_FOR_REQUEST = 0,
		CLIENT_READING_REQUEST = 1,
		CLIENT_READING_FILE = 2,
		CLIENT_PROCESSING_REQUEST = 3,
		CLIENT_SENDING_RESPONSE = 4,
		CLIENT_CLOSING = 5,
		CLIENT_DISCONNECTED = 6
	};

private:
	// Objects
	FileDescriptor _clientFd;
	int _socketFd;
	SocketAddress _localAddr;
	SocketAddress _remoteAddr;

	size_t _totalBytesRead;
	HttpRequest _request;
	HttpResponse _response;
	RingBuffer _readBuffer;
	const std::vector<Server> *_potentialServers;
	bool _serverFound;
	Server *_server;

	// State
	State _currentState;
	time_t _lastActivity;
	bool _keepAlive;

	void _processHTTPRequest();
	void _generateErrorResponse(int statusCode, const std::string &message = "");
	void _identifyServer();

public:
	Client();
	Client(FileDescriptor socketFd, SocketAddress clientAddr, SocketAddress remoteAddr);
	Client(const Client &other);
	Client &operator=(const Client &other);
	~Client();

	// Core operations
	void handleEvent(epoll_event event);
	void readRequest();
	void sendResponse();

	// State management
	State getCurrentState() const;
	void setState(State newState);
	bool isTimedOut() const;
	void updateActivity();

	// Accessors
	int getSocketFd() const;
	const SocketAddress &getLocalAddr() const;
	const SocketAddress &getRemoteAddr() const;
	const Server *getServer() const;
	const std::vector<Server> &getPotentialServers() const;
	void setPotentialServers(const std::vector<Server> &potentialServers);
	void setServer(const Server *server);

	void initializeServer();
};

#endif /* ********************************************************** CLIENT_H                                          \
		*/
